<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $repitencias->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $repitencias->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $repitencias->updated_at !!}</p>
</div>

<!-- Idalumno Field -->
<div class="form-group">
    {!! Form::label('idAlumno', 'Idalumno:') !!}
    <p>{!! $repitencias->idAlumno !!}</p>
</div>

<!-- Idcurso Field -->
<div class="form-group">
    {!! Form::label('idCurso', 'Idcurso:') !!}
    <p>{!! $repitencias->idCurso !!}</p>
</div>

