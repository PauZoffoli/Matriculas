<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $persona->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $persona->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $persona->updated_at !!}</p>
</div>

<!-- Pnombre Field -->
<div class="form-group">
    {!! Form::label('PNombre', 'Pnombre:') !!}
    <p>{!! $persona->PNombre !!}</p>
</div>

<!-- Snombre Field -->
<div class="form-group">
    {!! Form::label('SNombre', 'Snombre:') !!}
    <p>{!! $persona->SNombre !!}</p>
</div>

<!-- Tnombre Field -->
<div class="form-group">
    {!! Form::label('TNombre', 'Tnombre:') !!}
    <p>{!! $persona->TNombre !!}</p>
</div>

<!-- Appat Field -->
<div class="form-group">
    {!! Form::label('ApPat', 'Appat:') !!}
    <p>{!! $persona->ApPat !!}</p>
</div>

<!-- Apmat Field -->
<div class="form-group">
    {!! Form::label('ApMat', 'Apmat:') !!}
    <p>{!! $persona->ApMat !!}</p>
</div>

<!-- Fonofijo Field -->
<div class="form-group">
    {!! Form::label('fonoFijo', 'Fonofijo:') !!}
    <p>{!! $persona->fonoFijo !!}</p>
</div>

<!-- Fonocelu Field -->
<div class="form-group">
    {!! Form::label('fonoCelu', 'Fonocelu:') !!}
    <p>{!! $persona->fonoCelu !!}</p>
</div>

<!-- Iduser Field -->
<div class="form-group">
    {!! Form::label('idUser', 'Iduser:') !!}
    <p>{!! $persona->idUser !!}</p>
</div>

<!-- Rut Field -->
<div class="form-group">
    {!! Form::label('rut', 'Rut:') !!}
    <p>{!! $persona->rut !!}</p>
</div>

<!-- Tipopersona Field -->
<div class="form-group">
    {!! Form::label('tipoPersona', 'Tipopersona:') !!}
    <p>{!! $persona->tipoPersona !!}</p>
</div>

<!-- Genero Field -->
<div class="form-group">
    {!! Form::label('genero', 'Genero:') !!}
    <p>{!! $persona->genero !!}</p>
</div>

<!-- Email Field -->
<div class="form-group">
    {!! Form::label('email', 'Email:') !!}
    <p>{!! $persona->email !!}</p>
</div>

<!-- Fechanacimiento Field -->
<div class="form-group">
    {!! Form::label('fechaNacimiento', 'Fechanacimiento:') !!}
    <p>{!! $persona->fechaNacimiento !!}</p>
</div>

<!-- Fechadefuncion Field -->
<div class="form-group">
    {!! Form::label('fechaDefuncion', 'Fechadefuncion:') !!}
    <p>{!! $persona->fechaDefuncion !!}</p>
</div>

<!-- Estadocivil Field -->
<div class="form-group">
    {!! Form::label('estadoCivil', 'Estadocivil:') !!}
    <p>{!! $persona->estadoCivil !!}</p>
</div>

<!-- Iddireccion Field -->
<div class="form-group">
    {!! Form::label('idDireccion', 'Iddireccion:') !!}
    <p>{!! $persona->idDireccion !!}</p>
</div>

