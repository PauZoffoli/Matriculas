<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $curso->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $curso->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $curso->updated_at !!}</p>
</div>

<!-- Nivel Field -->
<div class="form-group">
    {!! Form::label('nivel', 'Nivel:') !!}
    <p>{!! $curso->nivel !!}</p>
</div>

<!-- Basicamedia Field -->
<div class="form-group">
    {!! Form::label('basicaMedia', 'Basicamedia:') !!}
    <p>{!! $curso->basicaMedia !!}</p>
</div>

<!-- Arancelanual Field -->
<div class="form-group">
    {!! Form::label('arancelAnual', 'Arancelanual:') !!}
    <p>{!! $curso->arancelAnual !!}</p>
</div>

