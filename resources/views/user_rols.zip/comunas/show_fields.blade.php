<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $comuna->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $comuna->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $comuna->updated_at !!}</p>
</div>

<!-- Codigounico Field -->
<div class="form-group">
    {!! Form::label('codigoUnico', 'Codigounico:') !!}
    <p>{!! $comuna->codigoUnico !!}</p>
</div>

<!-- Idprovincia Field -->
<div class="form-group">
    {!! Form::label('idProvincia', 'Idprovincia:') !!}
    <p>{!! $comuna->idProvincia !!}</p>
</div>

