<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $alumno->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $alumno->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $alumno->updated_at !!}</p>
</div>

<!-- Parentesco Field -->
<div class="form-group">
    {!! Form::label('parentesco', 'Parentesco:') !!}
    <p>{!! $alumno->parentesco !!}</p>
</div>

<!-- Otroparentesco Field -->
<div class="form-group">
    {!! Form::label('otroParentesco', 'Otroparentesco:') !!}
    <p>{!! $alumno->otroParentesco !!}</p>
</div>

<!-- Repitencias Field -->
<div class="form-group">
    {!! Form::label('repitencias', 'Repitencias:') !!}
    <p>{!! $alumno->repitencias !!}</p>
</div>

<!-- Condicion Field -->
<div class="form-group">
    {!! Form::label('condicion', 'Condicion:') !!}
    <p>{!! $alumno->condicion !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $alumno->estado !!}</p>
</div>

<!-- Estadocivilpadres Field -->
<div class="form-group">
    {!! Form::label('estadoCivilPadres', 'Estadocivilpadres:') !!}
    <p>{!! $alumno->estadoCivilPadres !!}</p>
</div>

<!-- Idpersona Field -->
<div class="form-group">
    {!! Form::label('idPersona', 'Idpersona:') !!}
    <p>{!! $alumno->idPersona !!}</p>
</div>

<!-- Idapoderado Field -->
<div class="form-group">
    {!! Form::label('idApoderado', 'Idapoderado:') !!}
    <p>{!! $alumno->idApoderado !!}</p>
</div>

<!-- Idcursoactual Field -->
<div class="form-group">
    {!! Form::label('idCursoActual', 'Idcursoactual:') !!}
    <p>{!! $alumno->idCursoActual !!}</p>
</div>

<!-- Idcursopostu Field -->
<div class="form-group">
    {!! Form::label('idCursoPostu', 'Idcursopostu:') !!}
    <p>{!! $alumno->idCursoPostu !!}</p>
</div>

