<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $alumnoResponsable->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $alumnoResponsable->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $alumnoResponsable->updated_at !!}</p>
</div>

<!-- Parentesco Field -->
<div class="form-group">
    {!! Form::label('parentesco', 'Parentesco:') !!}
    <p>{!! $alumnoResponsable->parentesco !!}</p>
</div>

<!-- Otroparentesco Field -->
<div class="form-group">
    {!! Form::label('otroParentesco', 'Otroparentesco:') !!}
    <p>{!! $alumnoResponsable->otroParentesco !!}</p>
</div>

<!-- Idpersona Field -->
<div class="form-group">
    {!! Form::label('idPersona', 'Idpersona:') !!}
    <p>{!! $alumnoResponsable->idPersona !!}</p>
</div>

<!-- Idalumno Field -->
<div class="form-group">
    {!! Form::label('idAlumno', 'Idalumno:') !!}
    <p>{!! $alumnoResponsable->idAlumno !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $alumnoResponsable->descripcion !!}</p>
</div>

