<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $direccion->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $direccion->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $direccion->updated_at !!}</p>
</div>

<!-- Idcomuna Field -->
<div class="form-group">
    {!! Form::label('idComuna', 'Idcomuna:') !!}
    <p>{!! $direccion->idComuna !!}</p>
</div>

<!-- Calle Field -->
<div class="form-group">
    {!! Form::label('calle', 'Calle:') !!}
    <p>{!! $direccion->calle !!}</p>
</div>

<!-- Nrocalle Field -->
<div class="form-group">
    {!! Form::label('nroCalle', 'Nrocalle:') !!}
    <p>{!! $direccion->nroCalle !!}</p>
</div>

<!-- Bloquetorre Field -->
<div class="form-group">
    {!! Form::label('bloqueTorre', 'Bloquetorre:') !!}
    <p>{!! $direccion->bloqueTorre !!}</p>
</div>

<!-- Dpto Field -->
<div class="form-group">
    {!! Form::label('dpto', 'Dpto:') !!}
    <p>{!! $direccion->dpto !!}</p>
</div>

