<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $provincia->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $provincia->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $provincia->updated_at !!}</p>
</div>

<!-- Nombreprov Field -->
<div class="form-group">
    {!! Form::label('nombreProv', 'Nombreprov:') !!}
    <p>{!! $provincia->nombreProv !!}</p>
</div>

<!-- Codigounico Field -->
<div class="form-group">
    {!! Form::label('codigoUnico', 'Codigounico:') !!}
    <p>{!! $provincia->codigoUnico !!}</p>
</div>

<!-- Idregion Field -->
<div class="form-group">
    {!! Form::label('idRegion', 'Idregion:') !!}
    <p>{!! $provincia->idRegion !!}</p>
</div>

