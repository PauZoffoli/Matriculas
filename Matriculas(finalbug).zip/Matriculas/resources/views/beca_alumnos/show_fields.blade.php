<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $becaAlumno->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $becaAlumno->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $becaAlumno->updated_at !!}</p>
</div>

<!-- Idalumno Field -->
<div class="form-group">
    {!! Form::label('idAlumno', 'Idalumno:') !!}
    <p>{!! $becaAlumno->idAlumno !!}</p>
</div>

<!-- Idbeca Field -->
<div class="form-group">
    {!! Form::label('idBeca', 'Idbeca:') !!}
    <p>{!! $becaAlumno->idBeca !!}</p>
</div>

