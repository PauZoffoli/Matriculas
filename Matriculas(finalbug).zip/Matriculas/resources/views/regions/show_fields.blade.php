<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $region->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $region->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $region->updated_at !!}</p>
</div>

<!-- Nombrereg Field -->
<div class="form-group">
    {!! Form::label('nombreReg', 'Nombrereg:') !!}
    <p>{!! $region->nombreReg !!}</p>
</div>

<!-- Regionord Field -->
<div class="form-group">
    {!! Form::label('regionOrd', 'Regionord:') !!}
    <p>{!! $region->regionOrd !!}</p>
</div>

<!-- Codigounico Field -->
<div class="form-group">
    {!! Form::label('codigoUnico', 'Codigounico:') !!}
    <p>{!! $region->codigoUnico !!}</p>
</div>

