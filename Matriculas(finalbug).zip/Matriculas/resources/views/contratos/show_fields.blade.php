<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $contrato->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $contrato->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $contrato->updated_at !!}</p>
</div>

<!-- Idapoderado Field -->
<div class="form-group">
    {!! Form::label('idApoderado', 'Idapoderado:') !!}
    <p>{!! $contrato->idApoderado !!}</p>
</div>

<!-- Urlcontrato Field -->
<div class="form-group">
    {!! Form::label('urlContrato', 'Urlcontrato:') !!}
    <p>{!! $contrato->urlContrato !!}</p>
</div>

<!-- Urlpagare Field -->
<div class="form-group">
    {!! Form::label('urlPagare', 'Urlpagare:') !!}
    <p>{!! $contrato->urlPagare !!}</p>
</div>

<!-- Urlcontratof Field -->
<div class="form-group">
    {!! Form::label('urlContratoF', 'Urlcontratof:') !!}
    <p>{!! $contrato->urlContratoF !!}</p>
</div>

<!-- Urlpagaref Field -->
<div class="form-group">
    {!! Form::label('urlPagareF', 'Urlpagaref:') !!}
    <p>{!! $contrato->urlPagareF !!}</p>
</div>

<!-- Nrocuotas Field -->
<div class="form-group">
    {!! Form::label('nroCuotas', 'Nrocuotas:') !!}
    <p>{!! $contrato->nroCuotas !!}</p>
</div>

<!-- Fechacontrato Field -->
<div class="form-group">
    {!! Form::label('fechaContrato', 'Fechacontrato:') !!}
    <p>{!! $contrato->fechaContrato !!}</p>
</div>

<!-- Anioacontratar Field -->
<div class="form-group">
    {!! Form::label('anioAContratar', 'Anioacontratar:') !!}
    <p>{!! $contrato->anioAContratar !!}</p>
</div>

<!-- Totalapagar Field -->
<div class="form-group">
    {!! Form::label('totalAPagar', 'Totalapagar:') !!}
    <p>{!! $contrato->totalAPagar !!}</p>
</div>

