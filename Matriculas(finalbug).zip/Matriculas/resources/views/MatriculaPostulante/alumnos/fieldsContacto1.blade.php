@extends('MatriculaPostulante.personas.fieldsPersonaContacto', 


    [
'PNombreLBL' => 'fichaAlumno[0][PNombrePContacto]',
'SNombreLBL' => 'fichaAlumno[0][SNombrePContacto]',
'TNombreLBL' => 'fichaAlumno[0][TNombrePContacto]',
'ApPatLBL' => 'fichaAlumno[0][ApPatPContacto]',
'ApMatLBL' => 'fichaAlumno[0][ApMatPContacto]',
'fonoFijoLBL' => 'fichaAlumno[0][fonoFijoPContacto]',
'fonoCeluLBL' => 'fichaAlumno[0][fonoCeluPContacto]',
'emailLBL' => 'fichaAlumno[0][emailPContacto]',
'parentescoLBL' => 'fichaAlumno[0][parentescoPContacto]',

'PNombreTXT' => null, 
'SNombreTXT' => null, 
'TNombreTXT' => null, 
'ApPatTXT' => null, 
'ApMatTXT' => null, 
'fonoFijoTXT' => null, 
'fonoCeluTXT' => null, 
'emailTXT' => null, 
'parentescoTXT' => null, 

    ])
