@extends('MatriculaPostulante.personas.fieldsPersonaContacto', 


    [
'PNombreLBL' => 'fichaAlumno[0][PNombreSContacto]',
'SNombreLBL' => 'fichaAlumno[0][SNombreSContacto]',
'TNombreLBL' => 'fichaAlumno[0][TNombreSContacto]',
'ApPatLBL' => 'fichaAlumno[0][ApPatSContacto]',
'ApMatLBL' => 'fichaAlumno[0][ApMatSContacto]',
'fonoFijoLBL' => 'fichaAlumno[0][fonoFijoSContacto]',
'fonoCeluLBL' => 'fichaAlumno[0][fonoCeluSContacto]',
'emailLBL' => 'fichaAlumno[0][emailSContacto]',
'parentescoLBL' => 'fichaAlumno[0][parentescoSContacto]',

'PNombreTXT' => null, 
'SNombreTXT' => null, 
'TNombreTXT' => null, 
'ApPatTXT' => null, 
'ApMatTXT' => null, 
'fonoFijoTXT' => null, 
'fonoCeluTXT' => null, 
'emailTXT' => null, 
'parentescoTXT' => null, 


    ])