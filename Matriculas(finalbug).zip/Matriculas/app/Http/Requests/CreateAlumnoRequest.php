<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Alumno;

class CreateAlumnoRequest extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
        /* if($this->blog)
    {
        if($this->user()->isAdmin()) return true;

        return Post::where('id', $this->blog)
                   ->where('user_id', $this->user()->id)->exists();
    }

    return true;*/
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return Alumno::$rules;
    }
}
