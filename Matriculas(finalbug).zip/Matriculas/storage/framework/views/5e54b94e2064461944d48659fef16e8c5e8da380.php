<table class="table table-responsive" id="contratos-table">
    <thead>
        <tr>
            <th>Idapoderado</th>
        <th>Urlcontrato</th>
        <th>Urlpagare</th>
        <th>Urlcontratof</th>
        <th>Urlpagaref</th>
        <th>Nrocuotas</th>
        <th>Fechacontrato</th>
        <th>Anioacontratar</th>
        <th>Totalapagar</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $contrato->idApoderado; ?></td>
            <td><?php echo $contrato->urlContrato; ?></td>
            <td><?php echo $contrato->urlPagare; ?></td>
            <td><?php echo $contrato->urlContratoF; ?></td>
            <td><?php echo $contrato->urlPagareF; ?></td>
            <td><?php echo $contrato->nroCuotas; ?></td>
            <td><?php echo $contrato->fechaContrato; ?></td>
            <td><?php echo $contrato->anioAContratar; ?></td>
            <td><?php echo $contrato->totalAPagar; ?></td>
            <td>
                <?php echo Form::open(['route' => ['contratos.destroy', $contrato->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('contratos.show', [$contrato->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('contratos.edit', [$contrato->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>