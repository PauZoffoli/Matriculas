<table class="table table-responsive" id="alumnos-table">
    <thead>
        <tr>
            <th>Idapoderado</th>
        <th>Fechanacimiento</th>
        <th>Parentesco</th>
        <th>Otroparentesco</th>
        <th>Genero</th>
        <th>Harepetido</th>
        <th>Correoal</th>
        <th>Cursoactual</th>
        <th>Cursopostular</th>
        <th>Iddireccion</th>
        <th>Nacionalidad</th>
        <th>Fechadefuncion</th>
        <th>Estado</th>
        <th>Estadocivilpadres</th>
        <th>Idpersona</th>
        <th>Pcursorepetido</th>
        <th>Scursorepetido</th>
        <th>Tcursorepetido</th>
        <th>Idficha</th>
        <th>Urlcontratofirmado</th>
        <th>Urlpagarefirmado</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $alumno->idApoderado; ?></td>
            <td><?php echo $alumno->fechaNacimiento; ?></td>
            <td><?php echo $alumno->parentesco; ?></td>
            <td><?php echo $alumno->otroParentesco; ?></td>
            <td><?php echo $alumno->genero; ?></td>
            <td><?php echo $alumno->haRepetido; ?></td>
            <td><?php echo $alumno->correoAl; ?></td>
            <td><?php echo $alumno->cursoActual; ?></td>
            <td><?php echo $alumno->cursoPostular; ?></td>
            <td><?php echo $alumno->idDireccion; ?></td>
            <td><?php echo $alumno->nacionalidad; ?></td>
            <td><?php echo $alumno->fechaDefuncion; ?></td>
            <td><?php echo $alumno->estado; ?></td>
            <td><?php echo $alumno->estadoCivilPadres; ?></td>
            <td><?php echo $alumno->idPersona; ?></td>
            <td><?php echo $alumno->PCursoRepetido; ?></td>
            <td><?php echo $alumno->SCursoRepetido; ?></td>
            <td><?php echo $alumno->TCursoRepetido; ?></td>
            <td><?php echo $alumno->idFicha; ?></td>
            <td><?php echo $alumno->urlContratoFirmado; ?></td>
            <td><?php echo $alumno->urlPagareFirmado; ?></td>
            <td>
                <?php echo Form::open(['route' => ['alumnos.destroy', $alumno->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('alumnos.show', [$alumno->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('alumnos.edit', [$alumno->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>