<table class="table table-responsive" id="personas-table">
    <thead>
        <tr>
            <th>Pnombre</th>
        <th>Snombre</th>
        <th>Tnombre</th>
        <th>Appat</th>
        <th>Apmat</th>
        <th>Fonofijo</th>
        <th>Fonocelu</th>
        <th>Iduser</th>
        <th>Rut</th>
        <th>Tipopersona</th>
        <th>Genero</th>
        <th>Email</th>
        <th>Fechanacimiento</th>
        <th>Fechadefuncion</th>
        <th>Estadocivil</th>
        <th>Iddireccion</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $persona->PNombre; ?></td>
            <td><?php echo $persona->SNombre; ?></td>
            <td><?php echo $persona->TNombre; ?></td>
            <td><?php echo $persona->ApPat; ?></td>
            <td><?php echo $persona->ApMat; ?></td>
            <td><?php echo $persona->fonoFijo; ?></td>
            <td><?php echo $persona->fonoCelu; ?></td>
            <td><?php echo $persona->idUser; ?></td>
            <td><?php echo $persona->rut; ?></td>
            <td><?php echo $persona->tipoPersona; ?></td>
            <td><?php echo $persona->genero; ?></td>
            <td><?php echo $persona->email; ?></td>
            <td><?php echo $persona->fechaNacimiento; ?></td>
            <td><?php echo $persona->fechaDefuncion; ?></td>
            <td><?php echo $persona->estadoCivil; ?></td>
            <td><?php echo $persona->idDireccion; ?></td>
            <td>
                <?php echo Form::open(['route' => ['personas.destroy', $persona->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('personas.show', [$persona->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('personas.edit', [$persona->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>