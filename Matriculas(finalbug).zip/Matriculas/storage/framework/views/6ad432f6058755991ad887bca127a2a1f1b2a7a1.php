<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Padres
        </h1>
    </section>
    <div class="content">
        <?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="box box-primary">
<div class="content-header ">
                    <?php echo Form::open(['route' => 'contactos.store']); ?>

                    <br>
 <?php echo Form::label('cantidadDeContactos', 'Seleccione la cantidad de contactos que desea inscribir:'); ?>

<?php echo Form::select('cantidadDeContactos', [0, 1,2,3,4,5, 6],  ( isset($_GET['cantidad']) ? $_GET['cantidad'] : null ),  array('id' => 'cantidadDeContactos', 'class' => 'form-control','placeholder' =>"Seleccione una opción", 'required' =>'true', 'onchange'=>"document.location.href = '/padres/create/?cantidad=' + this.value")); ?>

</div>
<?php echo e($array = null); ?>




<?php if(isset($_GET['cantidad'])): ?>
<?php
  $start = $_GET['cantidad'];
?>



<?php if($start != null): ?>
 

                      
<?php
   for ($i = 1; $i <= $start; $i++) {  ?>
                       
<section class="content-header">
        <h1>
           <?php echo e($i); ?> ) Datos del Padre o Madre
        </h1> <br>
</section>
       <div class="box box-success" style="background-color: #E4FDE4!important;">
           <div class="box-body">
               <div class="row">
                 
                 <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsContacto1', ['myValue' => $i], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                  
               </div>
           </div>
       </div>
                 
               
                

            
                    <?php  } ?>

                   
 
                    

<?php endif; ?>

<?php endif; ?>



<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

   
</div>

                  
                    <?php echo Form::close(); ?>

             
        </div>
    </div>

<script >


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>