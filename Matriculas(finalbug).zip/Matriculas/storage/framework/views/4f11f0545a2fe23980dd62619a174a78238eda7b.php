<!-- Parentesco Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('parentesco', 'Parentesco:'); ?>

    <?php echo Form::text('parentesco', null, ['class' => 'form-control']); ?>

</div>

<!-- Otroparentesco Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('otroParentesco', 'Otroparentesco:'); ?>

    <?php echo Form::text('otroParentesco', null, ['class' => 'form-control']); ?>

</div>

<!-- Repitencias Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('repitencias', 'Repitencias:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('repitencias', false); ?>

        <?php echo Form::checkbox('repitencias', '1', null); ?> 1
    </label>
</div>

<!-- Condicion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('condicion', 'Condicion:'); ?>

    <?php echo Form::text('condicion', null, ['class' => 'form-control']); ?>

</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <?php echo Form::text('estado', null, ['class' => 'form-control']); ?>

</div>

<!-- Estadocivilpadres Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estadoCivilPadres', 'Estadocivilpadres:'); ?>

    <?php echo Form::text('estadoCivilPadres', null, ['class' => 'form-control']); ?>

</div>

<!-- Idpersona Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idPersona', 'Idpersona:'); ?>

    <?php echo Form::number('idPersona', null, ['class' => 'form-control']); ?>

</div>

<!-- Idapoderado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idApoderado', 'Idapoderado:'); ?>

    <?php echo Form::number('idApoderado', null, ['class' => 'form-control']); ?>

</div>

<!-- Idcursoactual Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idCursoActual', 'Idcursoactual:'); ?>

    <?php echo Form::number('idCursoActual', null, ['class' => 'form-control']); ?>

</div>

<!-- Idcursopostu Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idCursoPostu', 'Idcursopostu:'); ?>

    <?php echo Form::number('idCursoPostu', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('alumnos.index'); ?>" class="btn btn-default">Cancel</a>
</div>
