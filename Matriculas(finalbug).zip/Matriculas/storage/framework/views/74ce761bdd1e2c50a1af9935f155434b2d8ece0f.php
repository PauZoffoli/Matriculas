<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Alumno
        </h1>
   </section>
   <div class="content">
<?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <div class="alert alert-warning"><span class="glyphicon glyphicon-ok"></span><em> ERROR en Repitencias</em></div>
  <?php if(Session::has('flash_message')): ?>
    <div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> <?php echo session('flash_message'); ?></em></div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>
       <div class="box box-primary">
           <div class="box-body">
               <div class="">
                   <?php echo Form::model($persona, ['route' => ['alumnosPostulantes.update', $persona->id], 'method' => 'patch']); ?>



<section class="content-header">
        <h1>
            1) Datos del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
</section>
       <div class="box box-success" style="background-color: #E4FDE4!important;">
           <div class="box-body">
               <div class="row">
                 
                 <?php echo $__env->make('MatriculaPostulante.alumnos.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
           </div>
       </div>

<section class="content-header">
        <h1>
           2) Ficha Social del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
</section>
       <div class="box box-success" style="background-color: #E4FDE4!important;">
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fields_ficha_alumno', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <div class="form-group col-sm-12">
                 

              
</div>

               </div>
           </div>
       </div>

<div id="esPadre">
<section class="content-header">

        <h1>
           3) Padre del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
</section>
       <div class="box box-success" style="background-color: #E4FDE4!important;">
           <div class="box-body">
               <div class="row">
               
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsPadre', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
           </div>
       </div>
</div>
<div id="esMadre">
<section class="content-header">
        <h1>
           4) Madre del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
</section>
       <div class="box box-success" style="background-color: #E4FDE4!important;">
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsMadre', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


               </div>
           </div>
       </div>
</div>

 <?php echo Form::label('cantidadDeContactosLBL', '¿Cuántos contactos quiere para su alumno?'); ?>

<?php echo Form::select('fichaAlumno[0][cantidadContactos]', [ 0,1, 2],  null ,  array('id' => 'cantidadDeContactos', 'class' => 'form-control','placeholder' =>"¿Cuántos contactos quiere para su alumno?", 'required' =>'true')); ?>

<br>
            
<div id="headerPrimerContacto" name="headerPrimerContacto" >
<section class="content-header" >
        <h1>
           5) Contacto Nro 1 del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
         <?php echo Form::label('padreOMadrePC', '¿El primer contacto es el padre?'); ?>

                 <?php echo Form::select('padreOMadrePC', [ 'No es el padre ni la madre','Padre' ,'Madre'],  null ,  array('id' => 'padreOMadrePC', 'class' => 'form-control','placeholder' =>"Seleccione una opción", 'required' =>'true')); ?>

          <br>
</section>
       <div class="box box-success" id="datosPrimerContacto" name="datosPrimerContacto" style="background-color: #E4FDE4!important;">
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsContacto1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
           </div>
       </div>
</div>                  

<div id="headerSegundoContacto" name="headerSegundoContacto" >
<section class="content-header">
        <h1>
          6)  Contacto Nro 2 del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> 
         <?php echo Form::label('padreOMadreSC', '¿El segundo contacto es la madre?'); ?>

                 <?php echo Form::select('padreOMadreSC', [ "0" =>'No es el padre ni la madre', 'Padre' ,'Madre'],  null ,  array('id' => 'padreOMadreSC', 'class' => 'form-control', 'placeholder' =>"Seleccione una opción", 'required' =>'true')); ?>

                 <br>
</section>

       <div class="box box-success" id="datosSegundoContacto" name="datosSegundoContacto"  style="background-color: #E4FDE4!important;">
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsContacto2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
           </div>
       </div>
</div>  


                      
                        
<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('alumnos.index'); ?>" class="btn btn-default">Cancel</a>
</div>


                   <?php echo Form::close(); ?>

               </div>
           </div>
       </div>
 




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>