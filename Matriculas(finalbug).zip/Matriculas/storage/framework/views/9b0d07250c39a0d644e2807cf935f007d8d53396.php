<?php $__env->startSection('content'); ?>
    <section class="content-header"  style="color: #5B5494;">
        <h1>
            DATOS DEL ALUMNO
        </h1>
   </section>
   <div class="content">
<?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <div class="alert alert-warning"><span class="glyphicon glyphicon-ok"></span><em>LOS SIGUIENTES DATOS SON ÚNICA Y EXCLUSIVAMENTE REFERIDOS AL ALUMNO</em></div>
  <?php if(Session::has('flash_message')): ?>
    <div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> <?php echo session('flash_message'); ?></em></div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>


       <div class="">
           <div class="box-body">
               <div class="">

                   <?php echo Form::model($persona, ['route' => ['alumnosPostulantes.update', $persona->id], 'method' => 'patch']); ?>


 <?php echo csrf_field(); ?>

 <div class="box box-solid box-primary" style="background-color: #E5ECFB!important;">

   <div class="pull-right">
      <div class="form-group  ">
 <?php echo Form::label('idCursoPostu', 'Curso a Postular para 2019:'); ?>


      <?php echo Form::select('alumno[idCursoPostu]', App\Enums\CursoEnum::getPossibleENUM(), ( isset($persona->alumno->idCursoPostu) ? $persona->alumno->idCursoPostu : null ) ,  array('id'=> 'alumno[idCursoPostu]', 'required' => 'true', 'class' => 'form-control', 'placeholder' => 'Seleccione el curso a postular' , "readonly"=>"readonly", 'disabled' => 'disabled')); ?>

  </div>
</div>
<section class="content-header">
        <h1>
            1) Datos del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

      
  </h1> <br>
   
      
</section>
         

           <div class="box-body">
               <div class="row">


<div class="box-body">
<!-- Idcomuna Field -->
<!-- Submit Field -->

<!-- Idcursopostu Field -->


                  <?php echo $__env->make('MatriculaPostulante.personas.fieldsPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
                 <?php echo $__env->make('MatriculaPostulante.alumnos.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <?php echo $__env->make('MatriculaPostulante.direccions.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
    
               </div>

                  
               </div>
           </div>
       </div>
<div class="box box-solid box-primary" style="background-color: #E5ECFB!important;">
<section class="content-header">
        <h1>
           2) Ficha Social del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
</section>
        <div class="form-group col-sm-12">

</div>
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fields_ficha_alumno', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <div class="form-group col-sm-12">
                 

              
</div>

               </div>
           </div>
       </div>

 <div class="box box-solid box-primary" style="background-color: #E5ECFB!important;">
<div id="esPadre">
<section class="content-header">

        <h1>
           3) Padre del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
</section>
        
           <div class="box-body">
               <div class="row">
               
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsPadre', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
           </div>
       </div>
</div>
<div class="box box-solid box-primary" style="background-color: #E5ECFB!important;">
<div id="esMadre">
<section class="content-header">
        <h1>
           4) Madre del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>
</section>
      
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsMadre', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


               </div>
           </div>
       </div>
</div>


<?php
  $cantContactos = null;
?>
<?php if(isset($persona->alumno->fichaAlumno)): ?>
  <?php if($persona->alumno->fichaAlumno->PNombrePContacto != null): ?>
    <?php $cantContactos = $cantContactos + 1  ?>
  <?php endif; ?>

  <?php if($persona->alumno->fichaAlumno->PNombreSContacto != null): ?>
    <?php $cantContactos = $cantContactos +1    ?>
  <?php endif; ?>
<?php endif; ?>

 <?php echo Form::label('cantidadDeContactosLBL', 'En caso de emergencia, ¿Cuántas personas desea dejar de contacto?'); ?>

<?php echo Form::select('fichaAlumno[0][cantidadContactos]', [ 0,1, 2],  $cantContactos ,  array('id' => 'cantidadDeContactos', 'class' => 'form-control','placeholder' =>"¿Cuántos contactos quiere para su alumno?", 'required' =>'true')); ?>

<br>

<div class="box box-solid box-primary"  id="headerPrimerContacto" name="headerPrimerContacto" style="background-color: #E5ECFB!important;">       
<section class="content-header" >
        <h1>
           5) Contacto Nro 1 del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

        </h1> <br>

<?php
// TODO ESTO ES PARA DEFINIR LA OPCIÓN ESCOGIDA DEL PRIMER Y SEGUNDO CONTACTO
  $primerContacto = null;
   $segundoContacto = null;
?>

<?php if(isset($persona->alumno->fichaAlumno->parentescoPContacto)): ?>


  <?php if(!(strcmp($persona->alumno->fichaAlumno->parentescoPContacto, "Padre"))): ?>
    <?php ($primerContacto =  1); ?>
  <?php endif; ?>

   <?php if(!(strcmp($persona->alumno->fichaAlumno->parentescoPContacto, "Madre"))): ?>
    <?php ($primerContacto =  2); ?>
  
  <?php endif; ?>

   <?php if((strcmp($persona->alumno->fichaAlumno->parentescoPContacto, "Padre") && strcmp($persona->alumno->fichaAlumno->parentescoPContacto, "Madre"))): ?>
    <?php ($primerContacto =  0); ?>
  <?php endif; ?>


<?php endif; ?>

<?php if(isset($persona->alumno->fichaAlumno->parentescoSContacto)): ?>


  <?php if(!(strcmp($persona->alumno->fichaAlumno->parentescoSContacto, "Padre"))): ?>
    <?php ($segundoContacto =  1); ?>
  <?php endif; ?>

   <?php if(!(strcmp($persona->alumno->fichaAlumno->parentescoSContacto, "Madre"))): ?>
    <?php ($segundoContacto =  2); ?>
  
  <?php endif; ?>

   <?php if((strcmp($persona->alumno->fichaAlumno->parentescoSContacto, "Padre") && strcmp($persona->alumno->fichaAlumno->parentescoSContacto, "Madre"))): ?>
    <?php ($segundoContacto =  0); ?>
  <?php endif; ?>


<?php endif; ?>


         <?php echo Form::label('padreOMadrePC', '¿Quién es el primer contacto?'); ?>

                 <?php echo Form::select('padreOMadrePC', [ 'No es el padre ni la madre','Padre' ,'Madre'],  
$primerContacto
                  ,  array('id' => 'padreOMadrePC', 'class' => 'form-control','placeholder' =>"Seleccione una opción", 'required' =>'true')); ?>

          <br>
</section>
    
          <div  id="datosPrimerContacto" name="datosPrimerContacto" >
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsContacto1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
           </div>
       </div>
</div>                  
<div class="box box-solid box-primary"  id="headerSegundoContacto" name="headerSegundoContacto"  style="background-color: #E5ECFB!important;">       
<section class="content-header">
        <h1>
          6)  Contacto Nro 2 del Alumno/a <?php echo e($persona->PNombre . ' ' . $persona->ApPat); ?>

          <br>
        </h1> 
         <?php echo Form::label('padreOMadreSC', '¿Quién es el segundo contacto?'); ?>

                 <?php echo Form::select('padreOMadreSC', [ "0" =>'No es el padre ni la madre', 'Padre' ,'Madre'], $segundoContacto ,  array('id' => 'padreOMadreSC', 'class' => 'form-control', 'placeholder' =>"Seleccione una opción", 'required' =>'true')); ?>

                 <br>
</section>

       <div id="datosSegundoContacto" name="datosSegundoContacto"  >
           <div class="box-body">
               <div class="row">
                 
                <?php echo $__env->make('MatriculaPostulante.alumnos.fieldsContacto2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
           </div>
       </div>
</div>  


                      
                        
<!-- Submit Field -->
<div class="form-group col-sm-12">
  <div class="pull-right">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

  </div>
</div>

                   <?php echo Form::close(); ?>

               </div>
           </div>
       </div>
 </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>