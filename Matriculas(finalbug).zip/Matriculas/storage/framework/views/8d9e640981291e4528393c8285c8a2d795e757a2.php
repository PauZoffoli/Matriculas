<?php $__env->startSection('content'); ?>
<div class="container">
	
  
  <br>
     <section class="jumbotron text-center">
        <div class="container">
          <h2 class="jumbotron-heading">Error</h2>
          <h2 class="lead text-muted">La sesión ha expirado :c</h2>
<h2 class="lead text-muted">Presione el botón para volver a empezar</h2>

          <p>
            <a href="<?php echo url('login'); ?>" class="btn btn-primary my-2">Iniciar Proceso de Matrículas</a>
          
          </p>
<?php if(session()->has('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(session()->get('errors')); ?>

    </div>
<?php endif; ?>
        </div>
      </section>

</div>
<br><br>
 <div class="img-responsive center-block">
                <img src="<?php echo e(asset('images/LogoGrandeIdop.jpg')); ?>"  class="img-responsive center-block" 
                     alt="User Image"/>

     </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>