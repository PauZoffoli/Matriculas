<table class="table table-responsive" id="apoderados-table">
    <thead>
        <tr>
            <th>Niveleducacional</th>
        <th>Profesion</th>
        <th>Nacionalidad</th>
        <th>Iddirecciones</th>
        <th>Fechanacimiento</th>
        <th>Estadoapoderado</th>
        <th>Idpersona</th>
        <th>PruebaPersona</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $apoderados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apoderado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $apoderado->nivelEducacional; ?></td>
            <td><?php echo $apoderado->profesion; ?></td>
            <td><?php echo $apoderado->nacionalidad; ?></td>
            <td><?php echo $apoderado->idDirecciones; ?></td>
            <td><?php echo $apoderado->fechaNacimiento; ?></td>
            <td><?php echo $apoderado->estadoApoderado; ?></td>
            <td><?php echo $apoderado->idPersona; ?></td>
             <td><?php echo $apoderado->persona->PNombre; ?></td>
            <td>
                <?php echo Form::open(['route' => ['apoderados.destroy', $apoderado->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('apoderados.show', [$apoderado->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('apoderados.edit', [$apoderado->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>