 <?php if(Auth::user()->personas->first()!=null): ?>
  
<li class="<?php echo e(Request::is('apoderadosPostulantes*') ? 'active' : ''); ?>">
    <a href="<?php echo route('apoderadosPostulantes.edit', Auth::user()->personas->first()->id); ?>"><i class="fa fa-edit"></i><span>Apoderados Postulantes</span></a>
</li>
<?php endif; ?>


<li class="<?php echo e(Request::is('alumnos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('alumnos.index'); ?>"><i class="fa fa-edit"></i><span>Alumnos</span></a>
</li>

<li class="<?php echo e(Request::is('alumnoResponsables*') ? 'active' : ''); ?>">
    <a href="<?php echo route('alumnoResponsables.index'); ?>"><i class="fa fa-edit"></i><span>Alumno Responsables</span></a>
</li>

<li class="<?php echo e(Request::is('apoderados*') ? 'active' : ''); ?>">
    <a href="<?php echo route('apoderados.index'); ?>"><i class="fa fa-edit"></i><span>Apoderados</span></a>
</li>

<li class="<?php echo e(Request::is('personas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('personas.index'); ?>"><i class="fa fa-edit"></i><span>Personas</span></a>
</li>

<li class="<?php echo e(Request::is('alumnos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('alumnos.index'); ?>"><i class="fa fa-edit"></i><span>Alumnos</span></a>
</li>

<li class="<?php echo e(Request::is('alumnoResponsables*') ? 'active' : ''); ?>">
    <a href="<?php echo route('alumnoResponsables.index'); ?>"><i class="fa fa-edit"></i><span>Alumno Responsables</span></a>
</li>

<li class="<?php echo e(Request::is('apoderados*') ? 'active' : ''); ?>">
    <a href="<?php echo route('apoderados.index'); ?>"><i class="fa fa-edit"></i><span>Apoderados</span></a>
</li>

<li class="<?php echo e(Request::is('comunas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('comunas.index'); ?>"><i class="fa fa-edit"></i><span>Comunas</span></a>
</li>

<li class="<?php echo e(Request::is('provincias*') ? 'active' : ''); ?>">
    <a href="<?php echo route('provincias.index'); ?>"><i class="fa fa-edit"></i><span>Provincias</span></a>
</li>

<li class="<?php echo e(Request::is('regions*') ? 'active' : ''); ?>">
    <a href="<?php echo route('regions.index'); ?>"><i class="fa fa-edit"></i><span>Regions</span></a>
</li>

<li class="<?php echo e(Request::is('direccions*') ? 'active' : ''); ?>">
    <a href="<?php echo route('direccions.index'); ?>"><i class="fa fa-edit"></i><span>Direccions</span></a>
</li>

<li class="<?php echo e(Request::is('contratos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('contratos.index'); ?>"><i class="fa fa-edit"></i><span>Contratos</span></a>
</li>

<li class="<?php echo e(Request::is('fichaAlumnos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('fichaAlumnos.index'); ?>"><i class="fa fa-edit"></i><span>Ficha Alumnos</span></a>
</li>

<li class="<?php echo e(Request::is('personas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('personas.index'); ?>"><i class="fa fa-edit"></i><span>Personas</span></a>
</li>

<li class="<?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
    <a href="<?php echo route('roles.index'); ?>"><i class="fa fa-edit"></i><span>Roles</span></a>
</li>

<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('users.index'); ?>"><i class="fa fa-edit"></i><span>Users</span></a>
</li>

<li class="<?php echo e(Request::is('userRols*') ? 'active' : ''); ?>">
    <a href="<?php echo route('userRols.index'); ?>"><i class="fa fa-edit"></i><span>User Rols</span></a>
</li>

<li class="<?php echo e(Request::is('cursos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('cursos.index'); ?>"><i class="fa fa-edit"></i><span>Cursos</span></a>
</li>

<li class="<?php echo e(Request::is('becas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('becas.index'); ?>"><i class="fa fa-edit"></i><span>Becas</span></a>
</li>

<li class="<?php echo e(Request::is('becaAlumnos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('becaAlumnos.index'); ?>"><i class="fa fa-edit"></i><span>Beca Alumnos</span></a>
</li>

<li class="<?php echo e(Request::is('repitencias*') ? 'active' : ''); ?>">
    <a href="<?php echo route('repitencias.index'); ?>"><i class="fa fa-edit"></i><span>Repitencias</span></a>
</li>

<li class="<?php echo e(Request::is('tipos*') ? 'active' : ''); ?>">
    <a href="<?php echo route('tipos.index'); ?>"><i class="fa fa-edit"></i><span>Tipos</span></a>
</li>

<li class="<?php echo e(Request::is('tipoPersonas*') ? 'active' : ''); ?>">
    <a href="<?php echo route('tipoPersonas.index'); ?>"><i class="fa fa-edit"></i><span>Tipo Personas</span></a>
</li>

