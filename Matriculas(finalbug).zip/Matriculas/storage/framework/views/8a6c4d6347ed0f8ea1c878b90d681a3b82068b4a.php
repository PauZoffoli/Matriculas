<?php echo $__env->make('MatriculaPostulante.personas.fieldsPersona', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<!-- APODERADOS -->
<!-- APODERADOS -->
<!-- APODERADOS -->

<!-- Idpersona Field https://laracasts.com/discuss/channels/laravel/form-model-binding-relations-how-to-bindpopulate-relations-in-a-form?page=1 -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idApoderado', 'IdApoderado:'); ?>

    <?php echo Form::number('apoderado[id]', null, ['class' => 'form-control']); ?>

</div>

<!-- Niveleducacional Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nivelEducacional', 'Niveleducacional:'); ?>

    <?php echo Form::text('apoderado[nivelEducacional]', null, ['class' => 'form-control']); ?>

</div>

<!-- Profesion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('profesion', 'Profesion:'); ?>

    <?php echo Form::text('apoderado[profesion]', null, ['class' => 'form-control']); ?>

</div>

<!-- Paisdeorigen Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('paisDeOrigen', 'Paisdeorigen:'); ?>

    <?php echo Form::text('apoderado[paisDeOrigen]', null, ['class' => 'form-control']); ?>

</div>

<!-- Idpersona Field https://laracasts.com/discuss/channels/laravel/form-model-binding-relations-how-to-bindpopulate-relations-in-a-form?page=1 -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idPersona', 'Idpersona:'); ?>

    <?php echo Form::number('apoderado[idPersona]', null, ['class' => 'form-control']); ?>

</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <?php echo Form::text('apoderado[estado]', null, ['class' => 'form-control']); ?>

</div>


<!-- MOSTRAMOS TODOS LOS ALUMNOS ASOCIADOS-->
<?php $index = 0; ?>
<?php $__currentLoopData = $persona->apoderado->alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>
        <?php echo e(Form::label('alumno', $alumno->persona->PNombre . ' ' . $alumno->persona->ApPat . ' ' . $alumno->persona->rut  )); ?>

       <?php echo e(Form::checkbox('alumnosCheck['. $index++ .']', $alumno, $persona->apoderado->alumnos->contains($alumno->id) )); ?>


       
    </p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('apoderados.index'); ?>" class="btn btn-default">Cancel</a>
</div>

