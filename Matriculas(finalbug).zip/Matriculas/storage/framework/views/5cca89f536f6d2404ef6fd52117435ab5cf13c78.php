<!--FICHA ALUMNO-->
<!--FICHA ALUMNO-->
<!--FICHA ALUMNO-->
<!--FICHA ALUMNO-->
<!--FICHA ALUMNO-->

<!-- Ingresofamiliarm Field -->
<div class="form-group col-sm-6" style="display: none">
   
    <?php echo Form::number('fichaAlumno[0][id]', null, ['class' => 'form-control']); ?>

</div>

<!-- Ingresofamiliarm Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ingresoFamiliarM', 'Ingresofamiliarm:'); ?>

    <?php echo Form::number('fichaAlumno[0][ingresoFamiliarM]', null, ['class' => 'form-control']); ?>

</div>

<!-- Causas Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('causas', 'Causas:'); ?>

    <?php echo Form::text('fichaAlumno[0][causas]', null, ['class' => 'form-control']); ?>

</div>

<!-- Nroconvivientes Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nroConvivientes', 'Nroconvivientes:'); ?>

    <?php echo Form::select('fichaAlumno[0][nroConvivientes]', [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17, 18, 19, 20], ( isset($persona->alumno->fichaAlumno[0]) ? $persona->alumno->fichaAlumno[0]['nroConvivientes'] : null ) ,  array('id'=> 'fichaAlumno[0][nroConvivientes]', 'class' => 'form-control', 'placeholder' => 'Seleccione el número de habitantes de la vivienda del alumno')); ?>


</div>

<!-- Totalhijos Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('totalHijos', 'Total de hermanos que viven con el alumno (pueden ser hermanos no sanguíneos, siempre que vivan con el alumno)'); ?>

    <?php echo Form::select('fichaAlumno[0][totalHijos]', [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17, 18, 19, 20], ( isset($persona->alumno->fichaAlumno[0]) ? $persona->alumno->fichaAlumno[0]['totalHijos'] : null ) ,  array('id'=> 'fichaAlumno[0][totalHijos]', 'class' => 'form-control', 'placeholder' => 'Seleccione el total de hermanos sanguíneos que tenga.')); ?>

</div>

<!-- Nrodehijo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nroDeHijo', 'Nrodehijo:'); ?>

    <?php echo Form::select('fichaAlumno[0][nroDeHijo]', [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17, 18, 19, 20], ( isset($persona->alumno->fichaAlumno[0]) ? $persona->alumno->fichaAlumno[0]['nroDeHijo'] : null ) ,  array('id'=> 'fichaAlumno[0][nroDeHijo]', 'class' => 'form-control', 'placeholder' => 'Seleccione su lugar entre los hermanos, por ejemplo: Yo soy el segundo hermano, escojo el lugar 2.')); ?>

</div>

<!-- Nrohermaidop Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nroHermaIDOP', 'Nrohermaidop:'); ?>

    <?php echo Form::number('fichaAlumno[0][nroHermaIDOP]', null, ['class' => 'form-control']); ?>

</div>

<!-- Tenenciavivienda Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tenenciaVivienda', 'Tenenciavivienda:'); ?>

    <?php echo Form::text('fichaAlumno[0][tenenciaVivienda]', null, ['class' => 'form-control']); ?>

</div>

<!-- Estudiacon Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estudiaCon', 'Estudiacon:'); ?>

    <?php echo Form::text('fichaAlumno[0][estudiaCon]', null, ['class' => 'form-control']); ?>

</div>

<!-- Isaprefonasa Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('isapreFonasa', 'Isaprefonasa:'); ?>

    <?php echo Form::select('fichaAlumno[0][isapreFonasa]', App\Enums\IsapreFonasaEnum::getPossibleENUM(), ( isset($persona->alumno->fichaAlumno[0]) ? $persona->alumno->fichaAlumno[0]['isapreFonasa'] : null ) ,  array('id'=> 'fichaAlumno[0][isapreFonasa]', 'class' => 'form-control', 'placeholder' => 'Seleccione Isapre o Fonasa')); ?>

    
</div>


<!-- Segurocomple Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('seguroComple', 'Segurocomple:'); ?>

    <label class="checkbox-inline">

        <?php echo Form::hidden('fichaAlumno[0][seguroComple]', '0'); ?>

        <?php echo Form::checkbox('fichaAlumno[0][seguroComple]', true); ?>

    </label>
</div>

<!-- Enfermedades Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('enfermedades', 'Enfermedades:'); ?>

    <?php echo Form::text('fichaAlumno[0][enfermedades]', null, ['class' => 'form-control']); ?>

</div>

<!-- Medicamentos Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('medicamentos', 'Medicamentos:'); ?>

    <?php echo Form::text('fichaAlumno[0][medicamentos]', null, ['class' => 'form-control']); ?>

</div>

<!-- Esalergico Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('esAlergico', 'Esalergico:'); ?>

    <label class="checkbox-inline">

<?php echo Form::hidden('fichaAlumno[0][esAlergico]', '0'); ?>

<?php echo Form::checkbox('fichaAlumno[0][esAlergico]', true); ?>

    </label>
</div>

<!-- Alergicoa Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('AlergicoA', 'Alergicoa:'); ?>


<?php echo Form::hidden('fichaAlumno[0][AlergicoA]', '0'); ?>

    <?php echo Form::text('fichaAlumno[0][AlergicoA]', null, ['class' => 'form-control']); ?>

</div>

<!-- Gruposanguineo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('grupoSanguineo', 'Gruposanguineo:'); ?>

    <?php echo Form::select('fichaAlumno[0][grupoSanguineo]', App\Enums\GrupoSanguineoEnum::getPossibleENUM(), ( isset($persona->alumno->fichaAlumno[0]) ? $persona->alumno->fichaAlumno[0]['grupoSanguineo'] : null ) ,  array('id'=> 'fichaAlumno[0][grupoSanguineo]', 'class' => 'form-control', 'placeholder' => 'Seleccione su Grupo Sanguineo')); ?>

</div>



<!-- viveConPadre Field -->
<div class="form-group col-sm-2">
    <?php echo Form::label('viveConPadre', 'viveConPadre:'); ?>

    <label class="checkbox-inline">

<?php echo Form::hidden('fichaAlumno[0][viveConPadre]', '0'); ?>

<?php echo Form::checkbox('fichaAlumno[0][viveConPadre]', true); ?>

    </label>
</div>

<!-- viveConMadre Field -->
<div class="form-group col-sm-2">
    <?php echo Form::label('viveConMadre', 'viveConMadre:'); ?>

    <label class="checkbox-inline">

<?php echo Form::hidden('fichaAlumno[0][viveConMadre]', '0'); ?>

<?php echo Form::checkbox('fichaAlumno[0][viveConMadre]', true); ?>

    </label>
</div>

<!-- viveConAbuelos Field -->
<div class="form-group col-sm-2">
    <?php echo Form::label('viveConAbuelos', 'viveConAbuelos:'); ?>

    <label class="checkbox-inline">

<?php echo Form::hidden('fichaAlumno[0][viveConAbuelos]', '0'); ?>

<?php echo Form::checkbox('fichaAlumno[0][viveConAbuelos]', true); ?>

    </label>
</div>


<!-- viveConTios Field -->
<div class="form-group col-sm-2">
    <?php echo Form::label('viveConTios', 'viveConTios:'); ?>

    <label class="checkbox-inline">

<?php echo Form::hidden('fichaAlumno[0][viveConTios]', '0'); ?>

<?php echo Form::checkbox('fichaAlumno[0][viveConTios]', true); ?>


    </label>
</div>


<!-- viveConTutor Field -->
<div class="form-group col-sm-2">
    <?php echo Form::label('viveConTutor', 'viveConTutor:'); ?>

    <label class="checkbox-inline">
     
<?php echo Form::hidden('fichaAlumno[0][viveConTutor]', '0'); ?>

<?php echo Form::checkbox('fichaAlumno[0][viveConTutor]', true); ?>



    </label>
</div>

<!-- observacionesSalud Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('observacionesSalud', 'observacionesSalud:'); ?>

    <?php echo Form::text('fichaAlumno[0][observacionesSalud]', null, ['class' => 'form-control']); ?>

</div>

