<!--para las personas ALUMNO Y APODERADO-->


<!-- Pnombrecand Field -->
<div class="form-group col-sm-4 <?php echo e($errors->has('PNombre') ? ' has-error' : ''); ?>">
    <?php echo Form::label('PNombre', 'Primer Nombre:'); ?>

    <?php echo Form::text('PNombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese primer nombre','required' => '', 'pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}", 'title' => 'No debe tener más de 30 caracteres']); ?>

</div>

<!-- idPersona Field -->
<div class="form-group col-sm-4" style="display: none">
    <?php echo Form::label('idPersona', 'idPersona:'); ?>

    <?php echo Form::text('id', null, ['class' => 'form-control']); ?>

</div>

<!-- Snombrecand Field -->
<div class="form-group col-sm-4 <?php echo e($errors->has('SNombre') ? ' has-error' : ''); ?>">
    <?php echo Form::label('SNombre', 'Segundo Nombre:',array('class' => 'opcional')); ?>

    <?php echo Form::text('SNombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese segundo nombre','pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}", 'title' => 'No puede tener más de 30 caracteres']); ?>

</div>


<!-- Tnombrecand Field -->
<div class="form-group col-sm-4 <?php echo e($errors->has('TNombre') ? ' has-error' : ''); ?>">
    <?php echo Form::label('TNombre', 'Tercer Nombre:',array('class' => 'opcional')); ?>

    <?php echo Form::text('TNombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese tercer nombre','pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}",  'title' => 'No puede tener más de 30 caracteres']); ?>

</div>


<!-- ApPat Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('ApPat') ? ' has-error' : ''); ?>">
    <?php echo Form::label('ApPat', 'Apellido Paterno:'); ?>

    <?php echo Form::text('ApPat', null, ['class' => 'form-control', 'placeholder' => 'Ingrese apellido paterno.','required' => '', 'pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}",  'title' => 'No puede tener más de 30 caracteres']); ?>

</div>

<!-- ApMat Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('ApMat') ? ' has-error' : ''); ?>">
    <?php echo Form::label('ApMat', 'Apellido Materno:'); ?>

    <?php echo Form::text('ApMat', null, ['class' => 'form-control', 'placeholder' => 'Ingrese apellido materno', 'pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}",  'title' => 'No puede tener más de 30 caracteres']); ?>

</div>

<!-- Genero Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('genero', 'Sexo:'); ?>

    <?php echo Form::select('genero', App\Enums\Genero::getPossibleENUM(), ( isset($persona->genero) ? $persona->genero : null ),  array('id' => 'genero', 'class' => 'form-control', 'required' => 'true', 'placeholder' => 'Seleccione sexo')); ?>

</div>


<!-- Fechanacimiento Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('fechaNacimiento') ? ' has-error' : ''); ?>">
    <?php echo Form::label('fechaNacimiento', 'Fecha de Nacimiento:'); ?>

    <?php echo Form::date('fechaNacimiento', (isset($persona->fechaNacimiento) && $persona->fechaNacimiento ? Carbon\Carbon::parse($persona->fechaNacimiento)->format('Y-m-d')  : date('Y-m-d')), ['class' => 'form-control', 'placeholder' => 'dd-mm-YYYY', 'required' => 'true']); ?>

</div>

<!-- Estadocivil Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('estadoCivil') ? ' has-error' : ''); ?>">
    <?php echo Form::label('estadoCivil', 'Estado Civil:'); ?>

    <?php echo Form::select('estadoCivil', App\Enums\EstadoCivil::getPossibleENUM(), ( isset($persona->estadoCivil) ? $persona->estadoCivil : null ),  array('id' => 'estadoCivil', 'class' => 'form-control', 'required' => 'true', 'placeholder' => 'Seleccione estado civil')); ?>

</div>





<!-- Fonofijoapo Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('fonoFijo') ? ' has-error' : ''); ?>">
    <?php echo Form::label('fonoFijo', 'Teléfono Fijo:',array('class' => 'opcional')); ?>

    <?php echo Form::tel('fonoFijo', null, ['class' => 'form-control', 'placeholder' => 'Ingrese teléfono fijo (Ej: 226213316)', 'pattern' => "[0-9]{9}", 'title' => 'No puede tener más de nueve dígitos']); ?>

</div>


