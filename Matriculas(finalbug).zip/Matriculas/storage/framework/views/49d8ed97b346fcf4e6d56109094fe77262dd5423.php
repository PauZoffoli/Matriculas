<!-- Correoapo Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <?php echo Form::label('email', 'Correo electrónico:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'ejemplo@gmail.com', 'maxlength' => "100", 'required' => 'true']); ?>

</div>



<!-- APODERADOS -->
<!-- APODERADOS -->
<!-- APODERADOS -->

<!-- Idpersona Field https://laracasts.com/discuss/channels/laravel/form-model-binding-relations-how-to-bindpopulate-relations-in-a-form?page=1 -->


<!-- Celular Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('fonoCelu') ? ' has-error' : ''); ?>">
    <?php echo Form::label('fonoCelu', 'Teléfono Celular:'); ?>

    <?php echo Form::tel('fonoCelu', null, ['class' => 'form-control', 'placeholder' => 'Ingrese teléfono celular (Ej: 984337683)','required' => 'true','pattern' => "[0-9]{9}", 'title' => 'No puede tener más de nueve dígitos']); ?>

</div>


<!-- Niveleducacional Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('nivelEducacional', 'Nivel Educacional:'); ?>

     <?php echo Form::select('apoderado[nivelEducacional]', App\Enums\NivelEducacionalEnum::getPossibleENUM(), ( isset($persona->apoderado->nivelEducacional) ? $persona->apoderado->nivelEducacional : null ),  array('id' => 'apoderado[nivelEducacional]', 'class' => 'form-control', 'placeholder' => 'Seleccione un nivel educacional', 'required' => 'true')); ?>

</div>

<!-- Profesion Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('profesion', 'Profesión/Oficio:'); ?>

    <?php echo Form::text('apoderado[profesion]', null, ['class' => 'form-control', 'maxlength' => "100", 'required' => "true", 'placeholder' => 'Ingrese su profesión o oficio']); ?>

</div>
<!-- Paisdeorigen Field -->
<div class="form-group col-sm-12">

	<?php echo Form::label('paisDeOrigen', 'Nacionalidad (Si tiene doble nacionalidad (Ejemplo: Chilena y otra) prefiera Chile:'); ?>

    <?php echo Form::select('apoderado[paisDeOrigen]', App\Enums\PaisEnum::getPossibleENUM(), ( isset($persona->apoderado->paisDeOrigen) ? $persona->apoderado->paisDeOrigen : 'Chile' ),  array('id' => 'apoderado[paisDeOrigen]', 'class' => 'form-control')); ?>


</div>




<!-- Idpersona Field https://laracasts.com/discuss/channels/laravel/form-model-binding-relations-how-to-bindpopulate-relations-in-a-form?page=1 -->
