<table class="table table-responsive" id="fichaAlumnos-table">
    <thead>
        <tr>
            <th>Ingresofamiliarm</th>
        <th>Causas</th>
        <th>Nroconvivientes</th>
        <th>Totalhijos</th>
        <th>Nrodehijo</th>
        <th>Nrohermaidop</th>
        <th>Tenenciavivienda</th>
        <th>Estudiacon</th>
        <th>Isaprefonasa</th>
        <th>Segurocomple</th>
        <th>Enfermedades</th>
        <th>Medicamentos</th>
        <th>Esalergico</th>
        <th>Alergicoa</th>
        <th>Gruposanguineo</th>
        <th>Idalumno</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $fichaAlumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fichaAlumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $fichaAlumno->ingresoFamiliarM; ?></td>
            <td><?php echo $fichaAlumno->causas; ?></td>
            <td><?php echo $fichaAlumno->nroConvivientes; ?></td>
            <td><?php echo $fichaAlumno->totalHijos; ?></td>
            <td><?php echo $fichaAlumno->nroDeHijo; ?></td>
            <td><?php echo $fichaAlumno->nroHermaIDOP; ?></td>
            <td><?php echo $fichaAlumno->tenenciaVivienda; ?></td>
            <td><?php echo $fichaAlumno->estudiaCon; ?></td>
            <td><?php echo $fichaAlumno->isapreFonasa; ?></td>
            <td><?php echo $fichaAlumno->seguroComple; ?></td>
            <td><?php echo $fichaAlumno->enfermedades; ?></td>
            <td><?php echo $fichaAlumno->medicamentos; ?></td>
            <td><?php echo $fichaAlumno->esAlergico; ?></td>
            <td><?php echo $fichaAlumno->AlergicoA; ?></td>
            <td><?php echo $fichaAlumno->grupoSanguineo; ?></td>
            <td><?php echo $fichaAlumno->idAlumno; ?></td>
            <td>
                <?php echo Form::open(['route' => ['fichaAlumnos.destroy', $fichaAlumno->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('fichaAlumnos.show', [$fichaAlumno->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('fichaAlumnos.edit', [$fichaAlumno->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>