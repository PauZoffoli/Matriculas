<!--para las personas ALUMNO Y APODERADO-->

<!-- Pnombre Field -->
<div class="form-group col-sm-4">
    <?php echo Form::label('PNombre', 'Pnombre:'); ?>

    <?php echo Form::text('PNombre', null, ['class' => 'form-control']); ?>

</div>

<!-- idPersona Field -->
<div class="form-group col-sm-4" style="display: none">
    <?php echo Form::label('idPersona', 'idPersona:'); ?>

    <?php echo Form::text('id', null, ['class' => 'form-control']); ?>

</div>


<div class="form-group col-sm-4">
    <?php echo Form::label('SNombre', 'Snombre:'); ?>

    <?php echo Form::text('SNombre', null, ['class' => 'form-control']); ?>

</div>

<!-- Tnombre Field -->
<div class="form-group col-sm-4 ">
    <?php echo Form::label('TNombre', 'Tnombre:'); ?>

    <?php echo Form::text('TNombre', null, ['class' => 'form-control']); ?>

</div>

<!-- Appat Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ApPat', 'Appat:'); ?>

    <?php echo Form::text('ApPat', null, ['class' => 'form-control']); ?>

</div>

<!-- Apmat Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ApMat', 'Apmat:'); ?>

    <?php echo Form::text('ApMat', null, ['class' => 'form-control']); ?>

</div>

<!-- Fonofijo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fonoFijo', 'Fonofijo:'); ?>

    <?php echo Form::number('fonoFijo', null, ['class' => 'form-control']); ?>

</div>

<!-- Fonocelu Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fonoCelu', 'Fonocelu:'); ?>

    <?php echo Form::number('fonoCelu', null, ['class' => 'form-control']); ?>

</div>

<!-- Iduser Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idUser', 'Iduser:'); ?>

    <?php echo Form::number('idUser', null, ['class' => 'form-control']); ?>

</div>

<!-- Rut Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('rut', 'Rut:'); ?>

    <?php echo Form::text('rut', null, ['class' => 'form-control']); ?>

</div>

<!-- Genero Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('genero', 'Genero:'); ?>

    <?php echo Form::select('genero', App\Enums\Genero::getPossibleENUM(), ( isset($persona->genero) ? $persona->genero : null ),  array('id' => 'genero', 'class' => 'form-control')); ?>

</div>



<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Fechanacimiento Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fechaNacimiento', 'Fechanacimiento:'); ?>

    <?php echo Form::date('fechaNacimiento', null, ['class' => 'form-control']); ?>

</div>

<!-- Estadocivil Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estadoCivil', 'Estadocivil:'); ?>

    <?php echo Form::select('estadoCivil', App\Enums\EstadoCivil::getPossibleENUM(), ( isset($persona->estadoCivil) ? $persona->estadoCivil : null ),  array('id' => 'estadoCivil', 'class' => 'form-control')); ?>

</div>

 <?php echo $__env->make('MatriculaPostulante.direccions.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>