<!--
/*$PNombreLBL = $asd;
$SNombreLBL = $asd;
$TNombreLBL = $asd;
$ApPatLBL = $asd;
$ApMatLBL = $asd;
$fonoFijoLBL = $asd;
$fonoCeluLBL = $asd;
$rutLBL = $asd;
$tipoPersonaLBL = $asd;
$generoLBL = $asd;
$emailLBL = $asd;
$fechaNacimientoLBL = $asd;
$fechaDefuncionLBL = $asd;
$estadoCivilLBL = $asd;
$idDireccionLBL = $asd;
$idUserLBL = $asd;


$PNombreTXT = $asd;
$SNombreTXT = $asd;
$TNombreTXT = $asd;
$ApPatTXT = $asd;
$ApMatTXT = $asd;
$fonoFijoTXT = $asd;
$fonoCeluTXT = $asd;
$rutTXT = $asd;
$tipoPersonaTXT = $asd;
$generoTXT = $asd;
$emailTXT = $asd;
$fechaNacimientoTXT = $asd;
$fechaDefuncionTXT = $asd;
$estadoCivilTXT = $asd;
$idDireccionTXT = $asd;
$idUserTXT = $asd;*/
-->

<!--para las personas ALUMNO Y APODERADO-->

<?php if(isset($rutLBL)): ?>

<div class="form-group col-sm-12 alert alert-info">
    <span class="glyphicon glyphicon-warning-sign"></span><em> En caso que realmente no se sepa el padre/madre del alumno, repetir los datos de uno de los dos en los campos "Padre" y "Madre" en ambos cuadros, y favor advertir de esta situación al momento de acercarse a nuestras oficinas para firmar el contrato</em>
</div>
<?php endif; ?>


<!-- SIN CAMBIOS SIN CAMBIOS-->
<!-- Pnombrecand Field -->
<div class="form-group col-sm-4 <?php echo e($errors->has('PNombre') ? ' has-error' : ''); ?>">
    <?php echo Form::label('PNombre', 'Primer Nombre:'); ?>

    <?php echo Form::text($PNombreLBL, ( isset($PNombreTXT) ? $PNombreTXT : null ), ['class' => 'form-control', 'placeholder' => 'Ingrese su primer nombre','required' => '', 'pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}", 'title' => 'No debe tener más de 30 caracteres']); ?>

</div>
 
<!-- Snombrecand Field -->
<div class="form-group col-sm-4 <?php echo e($errors->has('SNombre') ? ' has-error' : ''); ?>">
    <?php echo Form::label('SNombre', 'Segundo Nombre:' ,array('class' => 'opcional')); ?>

    <?php echo Form::text($SNombreLBL,  ( isset($SNombreTXT) ? $SNombreTXT : null ), ['class' => 'form-control', 'placeholder' => 'Ingrese su segundo nombre','pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}", 'title' => 'No puede tener más de 30 caracteres']); ?>

</div>

<!-- Tnombrecand Field -->
<div class="form-group col-sm-4 <?php echo e($errors->has('TNombre') ? ' has-error' : ''); ?>">
    <?php echo Form::label('TNombre', 'Tercer Nombre:',array('class' => 'opcional')); ?>

    <?php echo Form::text($TNombreLBL,  ( isset($TNombreTXT) ? $TNombreTXT :null  ), ['class' => 'form-control', 'placeholder' => 'Ingrese su tercer nombre','pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}",  'title' => 'No puede tener más de 30 caracteres']); ?>

</div>


<!-- ApPat Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('ApPatLBL') ? ' has-error' : ''); ?>">
    <?php echo Form::label('ApPat', 'Apellido Paterno:'); ?>

    <?php echo Form::text($ApPatLBL,  ( isset($ApPatTXT) ? $ApPatTXT : null  ), ['class' => 'form-control', 'placeholder' => 'Ingrese su apellido paterno.','required' => 'true', 'pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}",  'title' => 'No puede tener más de 30 caracteres']); ?>

</div>



<!-- ApMat Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('ApMatLBL') ? ' has-error' : ''); ?>">
    <?php echo Form::label('ApMat', 'Apellido Materno:'); ?>

    <?php echo Form::text($ApMatLBL,  ( isset($ApMatTXT) ? $ApMatTXT : null  ), ['class' => 'form-control', 'placeholder' => 'Ingrese su apellido materno', 'pattern' => "[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,30}",  'title' => 'No puede tener más de 30 caracteres']); ?>

</div>

<!-- Fonofijoapo Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('$fonoFijoLBL') ? ' has-error' : ''); ?>">
    <?php echo Form::label('fonoFijo', 'Teléfono Fijo:',array('class' => 'opcional')); ?>

    <?php echo Form::tel($fonoFijoLBL,  ( isset($fonoFijoTXT) ? $fonoFijoTXT : null ), ['class' => 'form-control', 'placeholder' => 'Ingrese su teléfono fijo en caso que posea (Ej: 226213316)', 'pattern' => "[0-9]{9}", 'title' => 'No puede tener más de nueve dígitos']); ?>

</div>


<!-- Fonoceluapo Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('fonoCeluLBL') ? ' has-error' : ''); ?>">
    <?php echo Form::label('fonoCelu', 'Teléfono Celular:'); ?>

    <?php echo Form::tel($fonoCeluLBL,  ( isset($fonoCeluTXT) ? $fonoCeluTXT : null ), ['class' => 'form-control', 'placeholder' => 'Ingrese su teléfono celular (Ej: 984337683)','required' => '','pattern' => "[0-9]{9}", 'title' => 'No puede tener más de nueve dígitos']); ?>

</div>


<?php if(isset($rutLBL)): ?>

<!-- Rut Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('rut', 'Rut:'); ?>

    <?php echo Form::text($rutLBL,  ( isset($rutTXT) ? $rutTXT : null ), ['class' => 'form-control','maxlength'=>"11" , 'required' => 'true','oninput'=>"checkRut(this)" , 'placeholder' => 'Ingrese el rut del alumno']); ?>


</div>
<?php endif; ?>

<?php if(isset($generoLBL)): ?>
<!-- Genero Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('generoLBL') ? ' has-error' : ''); ?>">
    <?php echo Form::label('genero', 'Genero:'); ?>


     <?php echo Form::select($generoLBL, App\Enums\Genero::getPossibleENUM(), ( isset($generoTXT) ? $generoTXT : null ),  array('id' => $generoLBL, 'class' => 'form-control', 'required' => 'true', 'placeholder' => "Seleccione el genero de la persona")); ?>

</div>

<?php endif; ?>


<!-- Correoapo Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email:',array('class' => 'opcional')); ?>

    <?php echo Form::email($emailLBL,  ( isset($emailTXT) ? $emailTXT : null ), ['class' => 'form-control']); ?>

</div>

<?php if(isset($fechaNacimientoLBL)): ?>

<!-- Fechanacimiento Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('fechaNacimientoLBL') ? ' has-error' : ''); ?>">
    <?php echo Form::label('fechaNacimiento', 'Fecha de Nacimiento:'); ?>

    <?php echo Form::date($fechaNacimientoLBL, (isset($fechaNacimientoTXT) && $fechaNacimientoTXT ? Carbon\Carbon::parse($fechaNacimientoTXT)->format('Y-m-d')  : null), ['class' => 'form-control', 'placeholder' => 'dd-mm-YYYY', 'required' => '']); ?>

</div>

<?php endif; ?>

<?php if(isset($estadoCivilLBL)): ?>
<!-- Estadocivil Field -->
<div class="form-group col-sm-3 <?php echo e($errors->has('estadoCivil') ? ' has-error' : ''); ?>">
    <?php echo Form::label('estadoCivil', 'Estado Civil:'); ?>

        <?php echo Form::select($estadoCivilLBL, App\Enums\EstadoCivil::getPossibleENUM(),  ( isset($estadoCivilTXT) ? $estadoCivilTXT : null ),  array('id' => $estadoCivilLBL, 'class' => 'form-control','required'=> 'true', 'placeholder' => "Seleccione el estado civil")); ?>

</div>


<?php endif; ?>

<?php if(isset($parentescoLBL)): ?> <!--SI EL APODERADO ES PADRE, PUESTO ASÍ LO ESCOGIO EN EL PARENTESCO-->
<?php if($parentescoLBL == "padre[parentesco]" ): ?>
    <!-- Parentesco Field -->
<div class="form-group col-sm-6" style="display: none;">
    <?php echo Form::label('parentesco', 'Padre:'); ?>

    <?php echo Form::select($parentescoLBL,  ["Padre" => "Padre"], "Padre",  array('id' => $parentescoLBL, 'class' => 'form-control')); ?>

</div>
<?php endif; ?>

<?php if($parentescoLBL == "madre[parentesco]"): ?>
    <!-- Parentesco Field -->
<div class="form-group col-sm-6" style="display: none;">
    <?php echo Form::label('parentesco', 'Madre:'); ?>

    <?php echo Form::select($parentescoLBL, ["Madre"=> "Madre"], "Madre",  array('id' => $parentescoLBL, 'class' => 'form-control')); ?>


</div>
<?php endif; ?>
<?php if($parentescoLBL != "madre[parentesco]" && $parentescoLBL != "padre[parentesco]"): ?>
    <!-- Parentesco Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('parentesco', 'Parentesco con el alumno:'); ?>

    <?php echo Form::select($parentescoLBL, App\Enums\ParentescoAlumnoResponsableEnum::getPossibleENUM(), ( isset($parentescoTXT) ? $parentescoTXT : null ),  array('id' => $parentescoLBL, 'class' => 'form-control', 'placeholder' => "Seleccione el parentesco del alumno con el contacto", 'required' => 'true')); ?>

</div>
<?php endif; ?>
<?php endif; ?>

<!-- Validador Rut-->
    <script src="<?php echo e(asset('js/validarRUT.js')); ?>"></script>