<table class="table table-responsive" id="alumnos-table">
    <thead>
        <tr>
            <th>Parentesco</th>
        <th>Otroparentesco</th>
        <th>Repitencias</th>
        <th>Condicion</th>
        <th>Estado</th>
        <th>Estadocivilpadres</th>
        <th>Idpersona</th>
        <th>Idapoderado</th>
        <th>Idcursoactual</th>
        <th>Idcursopostu</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $alumno->parentesco; ?></td>
            <td><?php echo $alumno->otroParentesco; ?></td>
            <td><?php echo $alumno->repitencias; ?></td>
            <td><?php echo $alumno->condicion; ?></td>
            <td><?php echo $alumno->estado; ?></td>
            <td><?php echo $alumno->estadoCivilPadres; ?></td>
            <td><?php echo $alumno->idPersona; ?></td>
            <td><?php echo $alumno->idApoderado; ?></td>
            <td><?php echo $alumno->idCursoActual; ?></td>
            <td><?php echo $alumno->idCursoPostu; ?></td>
            <td>
                <?php echo Form::open(['route' => ['alumnos.destroy', $alumno->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('alumnos.show', [$alumno->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('alumnos.edit', [$alumno->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>