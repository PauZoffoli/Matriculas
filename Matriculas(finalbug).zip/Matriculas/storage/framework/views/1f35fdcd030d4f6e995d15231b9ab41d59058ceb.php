<!-- Niveleducacional Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nivelEducacional', 'Niveleducacional:'); ?>

    <?php echo Form::text('nivelEducacional', null, ['class' => 'form-control']); ?>

</div>

<!-- Profesion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('profesion', 'Profesion:'); ?>

    <?php echo Form::text('profesion', null, ['class' => 'form-control']); ?>

</div>

<!-- Paisdeorigen Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('paisDeOrigen', 'Paisdeorigen:'); ?>

    <?php echo Form::text('paisDeOrigen', null, ['class' => 'form-control']); ?>

</div>

<!-- Idpersona Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('idPersona', 'Idpersona:'); ?>

    <?php echo Form::number('idPersona', null, ['class' => 'form-control']); ?>

</div>

<!-- Estado Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estado', 'Estado:'); ?>

    <?php echo Form::text('estado', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('apoderados.index'); ?>" class="btn btn-default">Cancel</a>
</div>
